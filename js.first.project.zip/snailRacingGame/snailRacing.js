document.getElementById("startButton").addEventListener("click", startRace);

function startRace() {
  const snails = document.querySelectorAll(".snail");
  snails.forEach((snail) => {
    snail.style.left = "0px"; // 초기 위치 설정
  });

  const interval = setInterval(() => {
    let raceOver = false;
    snails.forEach((snail) => {
      const currentLeft = parseInt(snail.style.left);
      const randomStep = Math.floor(Math.random() * 8); // 달팽이 속도 설정
      snail.style.left = currentLeft + randomStep + "px";

      if (currentLeft + randomStep >= window.innerWidth - 100) {
        // 경주 끝 조건
        raceOver = true;
        alert(`${snail.id}가 승리했습니다!`);
      }
    });

    if (raceOver) {
      clearInterval(interval);
    }
  }, 100);
}
